# Native Fairy-variant arena source

This directory contains the task-authored C++20 public client and private
referee used by the Fairy-Stockfish variant family. The referee owns one
persistent game, accepts authenticated Unix-socket requests, commits each
White move together with Black's reply, bounds requests to one command,
maintains an append-only transcript, and counts participant-only postgame
connections. `VARIANT` and `PROTOCOL` are required protected configuration;
the implementation contains no task-specific opening or result override.

The referee links the pinned Fairy-Stockfish rule objects and independently
checks every move returned by the separate opponent process before commit.
`ping` is restricted to root and exists only for the container health check.

This integration source is offered under GPL-3.0-or-later for compatibility
with Fairy-Stockfish. It is compiled with `-O2 -DNDEBUG`, warnings as errors,
and is never exposed under `/app`.
