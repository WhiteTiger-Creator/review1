# Python wheel provenance

`wheelhouse.tar.gz` contains the offline pytest and CTRF reporting toolchain.
The adjacent `SHA256SUMS` authenticates the deterministic bundle; its bundled
`requirements.txt` pins every upstream wheel by artifact hash.

The wheels were retrieved from <https://pypi.org/> on 2026-07-16 for Python
3.11 and are platform-independent `py3-none-any` artifacts. They are installed
with `--no-index` and `--require-hashes`, followed by `pip check`. Python is
used only by tests; gameplay, the public client, referee, and opponent are
native executables.

`pytest-json-ctrf==0.3.5` declares the MIT License in its wheel metadata but
does not include a separate license file in that artifact.

The wheelhouse uses sorted ustar members with owner and group zero and the
fixed timestamp `2026-07-19T00:00:00Z`; gzip stores neither an original
filename nor a timestamp.
