#!/bin/sh
set -eu

ARENA_SOCKET=${ARENA_SOCKET:-/run/arena/arena.sock}
export ARENA_SOCKET

rm -f -- "$ARENA_SOCKET"
/opt/arena-private/referee \
  --config /opt/arena-private/difficulty_knobs.conf \
  >>/opt/arena-private/referee.log 2>&1 &
referee_pid=$!

attempt=0
while ! /opt/arena-private/healthcheck.sh >/dev/null 2>&1; do
  if ! kill -0 "$referee_pid" 2>/dev/null; then
    echo "Fairy-variant referee failed during startup" >&2
    exit 1
  fi
  attempt=$((attempt + 1))
  if [ "$attempt" -ge 200 ]; then
    echo "Fairy-variant referee did not become ready" >&2
    exit 1
  fi
  sleep 0.1
done

exec "$@"
