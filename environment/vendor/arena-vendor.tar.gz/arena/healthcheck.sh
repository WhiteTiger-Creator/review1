#!/bin/sh
set -eu

response=$(/app/arena --wire ping)
test "$response" = "PONG
END"
