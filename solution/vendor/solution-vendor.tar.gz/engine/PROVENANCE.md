# Fairy-Stockfish source bundle

`fairy-stockfish-vendor.tar.gz` is a deterministic packaging archive
containing the complete pinned Fairy-Stockfish 14 release source, GPLv3 text,
authorship notice, explicit behavior-neutral compiler-compatibility patch,
detailed provenance, and internal checksum manifest. The adjacent manifest
authenticates the entire bundle before extraction, and the builder validates
the internal manifest before using any source.

Bundling changes only layout. It does not alter source, rules, openings,
evaluation, search, or strength. Variant and role-specific search policy are
supplied outside this shared bundle and documented by each task.
