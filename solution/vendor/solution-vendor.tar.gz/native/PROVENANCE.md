# Native Fairy-variant oracle source

`oracle_player.cpp` is the task-authored C++20 reference player for the
Fairy-Stockfish variant family. It uses only the documented live arena socket,
makes one request at a time, validates protocol/variant/turn/transcript fields,
stops on the first terminal response, and succeeds only on a genuine White
win with zero participant postgame requests.

The selected variant, protocol, node budget, and safety limit are supplied as
`ORACLE_VARIANT`, `ORACLE_PROTOCOL`, `ORACLE_NODES`, and
`ORACLE_MAX_TURNS`. The oracle engine is built separately from the same exact
upstream Fairy-Stockfish source as the opponent; only the disclosed search
policy differs.
